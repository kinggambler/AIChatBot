package cn.bugstack.chatbot.api.domain.baiduai.service;

import cn.bugstack.chatbot.api.domain.baiduai.IBaiduAI;
import cn.bugstack.chatbot.api.domain.baiduai.model.vo.BaiduAIAnswer;

import cn.bugstack.chatbot.api.domain.baiduai.model.vo.BaiduAIToken;
import com.alibaba.fastjson.JSON;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.io.IOException;

/**
 * @author
 * @description
 * @github
 * @Copyright
 */
@Service
public class BaiduAI implements IBaiduAI {

    private Logger logger = LoggerFactory.getLogger(BaiduAI.class);


    @Override
    public String doChatGPT(String accessToken, String question) throws IOException {

        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        // 代理地址；open.aiproxy.xyz、open2.aiproxy.xyz
        String url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/ernie_speed?access_token=" + accessToken;
        HttpPost post = new HttpPost(url);
        post.addHeader("Content-Type","application/json;charset=UTF-8");
        post.addHeader("Accept", "application/json");
        String paramJson = "{\n" +
                "   \"messages\": [\n" +
                "    {\"role\":\"user\",\"content\":\""+question+"\"}\n" +
                "   ]\n" +
                "}";

        StringEntity stringEntity = new StringEntity(paramJson, ContentType.create("text/json", "UTF-8"));
        post.setEntity(stringEntity);

        CloseableHttpResponse response = httpClient.execute(post);
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String jsonStr = EntityUtils.toString(response.getEntity());
            BaiduAIAnswer aiAnswer = JSON.parseObject(jsonStr, BaiduAIAnswer.class);
            String answers = new String();
            answers=aiAnswer.getResult();
            return answers.toString();
        } else {
            throw new RuntimeException("Baidu AI Answer Err Code is " + response.getStatusLine().getStatusCode());
        }
    }

    @Override
    public String getAIToken(String clientId, String clientSecret) throws IOException {

        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        //HttpPost post = new HttpPost("https://aip.baidubce.com/oauth/2.0/token?client_id=ZVdeoAqvvT98l4tkNKQKiMjE&client_secret=Bevma9r99oFSfDDD4TAldut10xrj2aZQ&grant_type=client_credentials");
        HttpPost post = new HttpPost("https://aip.baidubce.com/oauth/2.0/token?client_id="+clientId+"&client_secret="+clientSecret+"&grant_type=client_credentials");
        post.addHeader("Content-Type", "application/json");
        post.addHeader("Accept", "application/json");

        CloseableHttpResponse response = httpClient.execute(post);
        //String access_token="";
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String jsonStr = EntityUtils.toString(response.getEntity());
            BaiduAIToken aIToken = JSON.parseObject(jsonStr, BaiduAIToken.class);
            StringBuilder answers = new StringBuilder();
            String access_token = aIToken.getAccess_token();
            return access_token.toString();
        } else {
            throw new RuntimeException("Baidu AI Token Err Code is " + response.getStatusLine().getStatusCode());
        }
    }

}
