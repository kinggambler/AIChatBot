package cn.bugstack.chatbot.api.domain.zsxq.model.res;

/**
 * @author
 * @description 请求问答接口结果
 * @github
 * @Copyright
 */
public class AnswerRes {

    private boolean succeeded;

    public boolean isSucceeded() {
        return succeeded;
    }

    public void setSucceeded(boolean succeeded) {
        this.succeeded = succeeded;
    }

}
