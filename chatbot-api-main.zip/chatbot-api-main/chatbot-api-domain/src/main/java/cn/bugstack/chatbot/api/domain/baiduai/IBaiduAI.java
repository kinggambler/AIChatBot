package cn.bugstack.chatbot.api.domain.baiduai;

import java.io.IOException;

/**
 * @author
 * @description ChatGPT open ai 接口：https://beta.openai.com/account/api-keys
 * @github
 * @Copyright
 */
public interface IBaiduAI {

    String doChatGPT(String accessToken, String question) throws IOException;
    String getAIToken(String clientId, String clientSecret) throws IOException;
}
