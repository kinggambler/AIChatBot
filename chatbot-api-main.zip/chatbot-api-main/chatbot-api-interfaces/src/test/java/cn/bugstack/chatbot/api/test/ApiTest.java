package cn.bugstack.chatbot.api.test;

import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * @author
 * @description 单元测试
 * @github
 * @Copyright
 */
public class ApiTest {

    @Test
    public void base64(){
        String cronExpression = new String(Base64.getDecoder().decode("MC81MCAqICogKiAqID8="), StandardCharsets.UTF_8);
        System.out.println(cronExpression);
    }

    @Test
    public void query_unanswered_questions() throws IOException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        HttpGet get = new HttpGet("https://api.zsxq.com/v2/groups/88888815181222/topics?scope=all&count=20");

        get.addHeader("cookie", "sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22812255282484882%22%2C%22first_id%22%3A%2218ee62b6c0f7c5-02c8a7ff702994-4c657b58-1440000-18ee62b6c10103a%22%2C%22props%22%3A%7B%7D%2C%22identities%22%3A%22eyIkaWRlbnRpdHlfY29va2llX2lkIjoiMThlZTYyYjZjMGY3YzUtMDJjOGE3ZmY3MDI5OTQtNGM2NTdiNTgtMTQ0MDAwMC0xOGVlNjJiNmMxMDEwM2EiLCIkaWRlbnRpdHlfbG9naW5faWQiOiI4MTIyNTUyODI0ODQ4ODIifQ%3D%3D%22%2C%22history_login_id%22%3A%7B%22name%22%3A%22%24identity_login_id%22%2C%22value%22%3A%22812255282484882%22%7D%7D; zsxq_access_token=8EB447EA-E1AB-EE2C-EF90-B01D03D69869_96C2518AB64DADD1; zsxqsessionid=3eb1e266f879c4b8a32d9e4fe3424295; abtest_env=product");
        get.addHeader("Content-Type", "application/json; charset=UTF-8");

        CloseableHttpResponse response = httpClient.execute(get);
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String res = EntityUtils.toString(response.getEntity());
            System.out.println(res);
        } else {
            System.out.println(response.getStatusLine().getStatusCode());
        }
    }

    @Test
    public void answer() throws IOException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        HttpPost post = new HttpPost("https://api.zsxq.com/v2/topics/412884248251548/answer");
        post.addHeader("cookie", "知识星球个人cookie信息");
        post.addHeader("Content-Type", "application/json;charset=utf8");

        String paramJson = "{\n" +
                "  \"req_data\": {\n" +
                "    \"text\": \"自己去百度！\\n\",\n" +
                "    \"image_ids\": [],\n" +
                "    \"silenced\": false\n" +
                "  }\n" +
                "}";

        StringEntity stringEntity = new StringEntity(paramJson, ContentType.create("text/json", "UTF-8"));
        post.setEntity(stringEntity);

        CloseableHttpResponse response = httpClient.execute(post);
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String res = EntityUtils.toString(response.getEntity());
            System.out.println(res);
        } else {
            System.out.println(response.getStatusLine().getStatusCode());
        }
    }

    @Test
    public void test_chatGPT() throws IOException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        HttpPost post = new HttpPost("https://api.openai.com/v1/completions");
        post.addHeader("Content-Type", "application/json");
        post.addHeader("Authorization", "Bearer 自行申请 https://beta.openai.com/overview");

        String paramJson = "{\"model\": \"text-davinci-003\", \"prompt\": \"帮我写一个java冒泡排序\", \"temperature\": 0, \"max_tokens\": 1024}";

        StringEntity stringEntity = new StringEntity(paramJson, ContentType.create("text/json", "UTF-8"));
        post.setEntity(stringEntity);

        CloseableHttpResponse response = httpClient.execute(post);
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String res = EntityUtils.toString(response.getEntity());
            System.out.println(res);
        } else {
            System.out.println(response.getStatusLine().getStatusCode());
        }

    }

    @Test
    public void test_baiduGPT() throws IOException, JSONException {

        System.out.println("控制台编码：" + System.getProperty("console.encoding"));
        System.setProperty("console.encoding", "UTF-8");
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        HttpPost post = new HttpPost("https://aip.baidubce.com/oauth/2.0/token?client_id=ZVdeoAqvvT98l4tkNKQKiMjE&client_secret=Bevma9r99oFSfDDD4TAldut10xrj2aZQ&grant_type=client_credentials");
        post.addHeader("Content-Type", "application/json");
        post.addHeader("Accept", "application/json");


        // String paramJson = "{\"model\": \"text-davinci-003\", \"prompt\": \"帮我写一个java冒泡排序\", \"temperature\": 0, \"max_tokens\": 1024}";

        //StringEntity stringEntity = new StringEntity(paramJson, ContentType.create("text/json", "UTF-8"));
        //post.setEntity(stringEntity);

        CloseableHttpResponse response = httpClient.execute(post);
        String access_token = "";
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            String res = EntityUtils.toString(response.getEntity());
            JSONObject jsonObj = new JSONObject(res);
            access_token = jsonObj.getString("access_token");
            System.out.println(access_token);
        } else {
            System.out.println(response.getStatusLine().getStatusCode());
        }
        if (access_token != "") {
            String url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/ernie_speed?access_token=" + access_token;
            HttpPost post1 = new HttpPost(url);
            post1.addHeader("Content-Type", "application/json;charset=UTF-8");
            post1.addHeader("Accept", "application/json");

            String paramJson = "{\n" +
                    "   \"messages\": [\n" +
                    "    {\"role\":\"user\",\"content\":\"介绍一下北京\"}\n" +
                    "   ]\n" +
                    "}";

            StringEntity stringEntity = new StringEntity(paramJson, ContentType.create("text/json", "UTF-8"));
            post1.setEntity(stringEntity);

            CloseableHttpResponse response1 = httpClient.execute(post1);
            if (response1.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                String res = EntityUtils.toString(response1.getEntity(), "UTF-8");
                //System.setProperty("console.encoding", "UTF-8");
                JSONObject jsonObj = new JSONObject(res);
                String result = jsonObj.getString("result");
                System.setOut(new PrintStream(System.out, true, "UTF-8"));
                System.out.println(result);
                System.out.println(res);
                System.out.println("你好！");
            } else {
                System.out.println(response1.getStatusLine().getStatusCode());
            }
        }
    }
}
