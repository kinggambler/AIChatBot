# 第4节：对接ChatGPT，调用接口

## 资料

- ChatGPT：[https://chat.openai.com/chat](https://chat.openai.com/chat)
- ApiKeys：[https://beta.openai.com/account/api-keys](https://beta.openai.com/account/api-keys) - 在这个里申请 SECRET KEY，如果没有申请成功可以联系小傅哥，微信：fustack - 但这个申请付费的，本身也需要购买虚拟电话号码和连接费用。所以申请价格20元。