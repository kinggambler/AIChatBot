/**
 * @description
 * @author
 * @github
 * @Copyright
 */
package cn.bugstack.chatbot.api.infrastructure;